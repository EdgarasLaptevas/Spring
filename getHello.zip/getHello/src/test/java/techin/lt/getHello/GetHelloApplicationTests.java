package techin.lt.getHello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
